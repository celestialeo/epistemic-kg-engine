"""Shared semantic review and chapter-wide novelty checks."""
from typing import Literal
from pydantic import Field, create_model
from .records import Record, batches
from .registry import Concept, FactIndex
from .batching import ask_keyed
from .models import ModelResponseError
from .health import finish_item
from .events import EVENT_POLICY, kind_error


from .relations import DEFAULT_RELATIONS

# Starting vocabulary, not an admission whitelist. New predicates undergo registry review.
BACKGROUND_RELATIONS = set(DEFAULT_RELATIONS)


class Proposal(Record):
    source: Concept | None = None
    target: Concept
    relation: str = Field(min_length=1, max_length=80)
    relation_definition: str = Field(min_length=1, max_length=400)
    confidence: float = Field(ge=0, le=1)
    reason: str = Field(min_length=1, max_length=800)
    gap_ids: list[str] = Field(min_length=1, description="Supplied knowledge gaps this assertion helps answer")
    added_knowledge: str = Field(min_length=1,
        description="What this assertion adds beyond the chapter and known facts")
    conditions: str | None = None
    modality: str | None = None


class Expansion(Record):
    gap_analysis: str = Field(min_length=1,
        description="Concise assessment of missing knowledge before proposing assertions, not private chain-of-thought")
    proposals: list[Proposal]
    reason: str = Field(min_length=1, max_length=800)


class Review(Record):
    candidate_id: str
    semantics_valid: bool
    direction_valid: bool
    types_valid: bool
    no_contradiction: bool
    certain: bool
    evidence_status: Literal["supported", "unsupported", "not_applicable"]
    domain_relevance: float = Field(ge=0, le=1)
    reason: str = Field(min_length=1, max_length=1200)


class Response(Record):
    candidate_id: str
    position: Literal["defend", "withdraw"]
    reason: str = Field(min_length=1, max_length=1200)


class Verdict(Review):
    accept: bool
    objections_resolved: bool


class DocumentVerdict(Verdict):
    evidence_status: Literal["supported", "unsupported"] = Field(
        description="Required quote-entailment decision for this DOCUMENT fact; evidence always applies")
    rejection_categories: list[Literal["meaning_changed", "quote_too_short", "wrong_direction",
        "wrong_kind", "unsupported_claim", "contradiction", "uncertain"]] = Field(
        description="Empty for acceptance; otherwise all applicable causes. quote_too_short means a longer source span supports the claim.")


class BackgroundReview(Review):
    evidence_status: Literal["not_applicable"]
    chapter_related: bool
    related_topic: str | None = Field(description="Copy one exact chapter topic when related, otherwise null")


class BackgroundCritique(BackgroundReview):
    objections: list[str] = Field(description="Concrete substantive objections; empty when there is no objection")


class BackgroundVerdict(BackgroundReview):
    accept: bool
    objections_resolved: bool
    gap_addressed: bool


class Novelty(Record):
    status: Literal["new", "duplicate", "uncertain"]
    evidence_ids: list[str]
    related_reference_ids: list[str] = Field(default_factory=list,
        description="References containing part of the assertion; retained for comparison across batches")
    reason: str = Field(min_length=1, max_length=800)


COMMON_POLICY = (
    "Every endpoint must be a standalone concept, never a statement or context-dependent reference. "
    "Express the assertion through a precise relation, with qualifications in conditions and modality. "
    "Evaluate the literal SOURCE relation TARGET under its relation definition, conditions and evidence. "
    "Concept names identify shared nodes across contexts; infer their contextual meaning from the relationship "
    "and supplied source material, not from separate node senses or an exhaustive node definition. "
    "A structural part is not a subtype; an event's location is not its physical component. "
    "Keep direction, causal strength, negation, conditions and specificity. "
    "Read conditions and modality as part of the assertion, including negation; preserve them in proposals. "
    "Never broaden a concept, invent an omitted action, or upgrade 'helps' to 'primary'. "
)
DOCUMENT_POLICY = EVENT_POLICY + COMMON_POLICY + (
    "Check that all participants, locations, negation and qualifications survive in the relation and its "
    "conditions and modality. Preserve collective scope without inventing pairwise routes. "
    "These are DOCUMENT candidates. The exact quote must entail THIS relation, including both endpoints, meaning, "
    "direction and qualifications; co-occurrence is insufficient. Outside knowledge cannot repair missing evidence. "
    "A quote may span multiple adjacent sentences. Judge entailment, not whether it literally contains the "
    "relation key. Mark quote_too_short only if the supplied source context contains the missing support. "
)
BACKGROUND_POLICY = COMMON_POLICY + (
    "Use a precise predicate appropriate to the asserted meaning; new predicates require schema validation. "
    "These are BACKGROUND candidates. Use well-established general knowledge. Accept a true, correctly directed "
    "relation with compatible endpoint kinds when it answers a useful knowledge gap for the WHOLE chapter. "
    "The source context establishes what needs explaining, not a boundary on what you may know. "
    "Use your own general understanding; no external texts or citations are requested. "
    "New concepts and predicates are permitted. A chapter's mention of a function does not fully explain it. "
    "Summaries and short concept definitions are fallible aids; do not infer restrictions they do not state. "
    "Absence from the text is NOT an objection. Missing text support is never a contradiction. Reject false, uncertain, or off-topic claims. "
    "Set chapter_related=true when you can identify the chapter topic it explains; copy that exact topic into "
    "related_topic. Relevance is to the whole chapter, never just the seed's original paragraph. "
    "Preserve scientific conditions and do not contradict the chapter. Contradiction requires incompatible "
    "assertions under matching conditions, not absence of support, a different contributor, or different wording. "
    "Do not confuse a concept with text describing it or invent claims about where information originated. "
    "Keep verdicts and explanations consistent and concise. "
    "Background evidence_status must be not_applicable. A model judgment is not external factual verification. "
)
NOVELTY_POLICY = (
    "Your only task is informational novelty: is the candidate assertion already stated or implied by the "
    "supplied references without adding outside subject knowledge? Do not judge truth, plausibility, "
    "chapter relevance, usefulness, or contradiction. A false or conflicting assertion may still be new; "
    "the debate handles those questions. Compare meaning, direction, scope, conditions and modality, not "
    "word overlap. Paraphrases, aliases, equivalent inverse phrasing, or recombinations containing no new "
    "information are duplicates. Mere relatedness, shared endpoints, or rearranged words expressing a "
    "different assertion are insufficient. Broader assertions, changed conditions and genuinely additional "
    "information are not automatically duplicates. Use general linguistic understanding to resolve names "
    "and wording, but never supply an unstated subject-matter premise to derive a duplicate. "
    "Return duplicate with supporting evidence_ids only when the references entail the asserted information. "
    "Otherwise return new. Use uncertain only for a concrete ambiguity preventing this comparison, "
    "never because the candidate lacks source support. Identify related_reference_ids for partial overlaps "
    "and assertions about the same subjects under comparable conditions, even when not duplicates. "
    "Retain those references without judging whether they conflict. This lets information distributed "
    "across reference pages be combined and gives the debate relevant comparison context."
)


def index_complete(rows, candidates, trace, role):
    expected = {c["id"] for c in candidates}
    actual = [r.candidate_id for r in rows]
    valid = len(actual) == len(set(actual)) and set(actual) == expected
    trace.emit("debate.ids_validated", role=role, expected=sorted(expected), actual=actual, valid=valid)
    if not valid:
        raise ValueError(f"{role}: return exactly one record per candidate; expected {sorted(expected)}, got {actual}")
    return {r.candidate_id: r.model_dump() for r in rows}


def validate_background_review(result, chapter):
    if result.chapter_related and result.related_topic not in chapter["topics"]:
        raise ValueError("A related background fact must cite an exact supplied chapter topic")
    if not result.chapter_related and result.related_topic is not None:
        raise ValueError("An unrelated fact must not cite a related topic")
    if isinstance(result, BackgroundCritique):
        if any(not objection.strip() for objection in result.objections):
            raise ValueError("Use an empty objections list instead of an empty objection")
        checks = (result.semantics_valid, result.direction_valid, result.types_valid,
                  result.no_contradiction, result.certain, result.chapter_related)
        if not result.objections and not all(checks):
            raise ValueError("Explain a failed critic check as a concrete objection, or correct the check")


def withdraw_candidate(row, response, trace):
    row.update(rebuttal=response, accepted=False, score=None, review_status="withdrawn",
               decision_reason="Proposer withdrew: " + response["reason"],
               verification_basis="model_knowledge" if row["origin"] == "background" else "quote_entailment_model_review")
    trace.emit("debate.withdrawn", entity_id=row["id"], decision=row)


def review_batch(models, role, instruction, payload, row_schema, candidates, trace, entity_id):
    fields = {}
    for candidate in candidates:
        identifier = candidate["id"]
        row = create_model(f"{role}_{identifier}", __base__=row_schema, candidate_id=(Literal[identifier], ...))
        fields[identifier] = (row, ...)
    schema = create_model(f"{role}_results", __base__=Record, **fields)
    def validate(result):
        index_complete(list(result.__dict__.values()), candidates, trace, role)
        for value in result.__dict__.values():
            if isinstance(value, BackgroundReview):
                validate_background_review(value, payload["chapter"])
    result = models.ask(role, instruction + " Return an object keyed by the exact candidate IDs.",
        payload, schema, entity_id, validator=validate)
    return {identifier: getattr(result, identifier).model_dump() for identifier in fields}


def review_context(row, chunk, outline, concepts):
    row["endpoint_kinds"] = {k: (row.get(k + "_mention") or concepts.entries[row[k]])["kind"]
                             for k in ("source", "target")}
    context = {"candidate": {k: row[k] for k in (
        "id", "source", "target", "relation", "relation_definition", "origin", "reason")},
        "concepts": [{field: concepts.entries[row[k]][field] for field in ("name", "definition", "kind")}
                     for k in ("source", "target")],
        "chapter": {k: outline[k] for k in ("overview", "topics")}}
    context["candidate"].update(conditions=row.get("conditions"), modality=row.get("modality"))
    if row["origin"] == "document":
        context.update(quote=row.get("evidence"), source_chunk=row.get("evidence_context", chunk["text"]))
    else:
        context["chapter"]["concepts"] = getattr(concepts, "chapter_names", []) or sorted(concepts.entries)
        context.update(source_chunk=chunk["text"], source_context=row.get("source_context", []),
                       gaps=row.get("gaps", []), gap_analysis=row.get("gap_analysis"),
                       added_knowledge=row.get("added_knowledge"),
                       known_seed_facts=row.get("known_seed_facts", []),
                       comparison_references=row.get("novelty_references", []))
    return context


def review_candidate(row, chunk, outline, concepts, models, trace, threshold):
    if row["origin"] == "background":
        review_background_many([row], {row["chunk_id"]: chunk}, outline, concepts, models, trace)
        return row
    context = review_context(row, chunk, outline, concepts)
    policy = DOCUMENT_POLICY
    critic = review_batch(models, "critic", policy +
        "Independently challenge the precise relation. Explain any invalidity and keep boolean checks "
        "consistent with your reasoning. Do not give a category error a passing semantics/types check.",
        context, Review, [row], trace, row["id"])[row["id"]]
    response = review_batch(models, "proposer_rebuttal", policy +
        "Address the critic's concrete objection. Defend a sound relation or withdraw an unsound one. "
        "Do not change the proposed endpoints or meaning.",
        {**context, "objection": critic["reason"]}, Response, [row], trace, row["id"])[row["id"]]
    row.update(critic=critic, rebuttal=response)
    if response["position"] == "withdraw":
        withdraw_candidate(row, response, trace)
        return row
    # No critic scores, boolean verdicts, confidence, or defend/withdraw position
    # are shown to the judge. It must adjudicate the actual statement and arguments.
    verdict = review_batch(models, "judge", policy +
        "Make your own decision. You see arguments, not other agents' verdicts or scores. "
        "Assess each validity condition independently. An argument conceding or defending a claim is not evidence. "
        "Accept only when all semantic conditions pass and all substantive objections are resolved. "
        "Explain explicitly why a raised objection is resolved or still valid.",
        {**context, "objection": critic["reason"], "reply": response["reason"]},
        DocumentVerdict, [row], trace, row["id"])[row["id"]]
    row.update(critic=critic, rebuttal=response)
    return apply_verdict(row, verdict, trace, threshold)


def apply_verdict(row, verdict, trace, threshold):
    gates = {k: verdict[k] for k in ("semantics_valid", "direction_valid", "types_valid",
                                   "no_contradiction", "certain", "objections_resolved")}
    gates["evidence"] = verdict["evidence_status"] == ("supported" if row["origin"] == "document" else "not_applicable")
    gates["relevance"] = verdict.get("chapter_related", False) if row["origin"] == "background" else verdict["domain_relevance"] >= threshold
    if row["origin"] == "background":
        gates["gap_addressed"] = verdict["gap_addressed"]
    kinds = row.get("endpoint_kinds")
    # Background predicates are open-ended; their contracts and endpoint kinds
    # are judged semantically, without a fixed predicate-specific admission rule.
    type_error = kind_error(row["relation"], kinds["source"], kinds["target"]) if kinds and row["origin"] == "document" else None
    gates["event_contract"] = type_error is None
    accepted = verdict["accept"] and all(gates.values())
    failed = [k for k, valid in gates.items() if not valid]
    row.update(judge=verdict, gates=gates, score=verdict["domain_relevance"],
               threshold=threshold, accepted=accepted,
               decision_reason=verdict["reason"] + (" Failed gates: " + ", ".join(failed) if failed else "") +
                               (" " + type_error if type_error else ""),
               verification_basis="quote_entailment_model_review" if row["origin"] == "document" else "model_knowledge")
    if row["origin"] == "document":
        categories = set(verdict.get("rejection_categories", [])) if not accepted else set()
        if not accepted:
            for gate, category in (("direction_valid", "wrong_direction"), ("types_valid", "wrong_kind"),
                                   ("event_contract", "wrong_kind")):
                if not gates[gate]:
                    categories.add(category)
            if not categories:
                categories.add("unsupported_claim")
        row["rejection_categories"] = sorted(categories)
    if verdict["accept"] != all(gates.values()):
        trace.emit("debate.verdict_conflict", entity_id=row["id"], verdict=verdict, gates=gates)
    trace.emit("debate.adjudicated", entity_id=row["id"], candidate=row)
    return row


def review_extractions(extractions, chunks, outline, concepts, facts, models, trace):
    by_chunk = {c["id"]: c for c in chunks}
    by_extraction = {e["chunk_id"]: e for e in extractions}
    decisions = []
    quality = {e["chunk_id"]: dict(chunk_id=e["chunk_id"], reviewed=0, accepted=0,
                                  rejected=0, unresolved=0) for e in extractions}
    rows = [row for e in extractions for row in e["relation_proposals"]]

    def review_page(page):
        items = [dict(id=row["id"], **review_context(row, by_chunk[row["chunk_id"]], outline, concepts)) for row in page]
        def validate(item, result):
            if result.candidate_id != item["id"]:
                raise ValueError("Review candidate_id must match its item ID")
            if result.accept and result.rejection_categories:
                raise ValueError("Accepted relations must have no rejection categories")
            if not result.accept and not result.rejection_categories:
                raise ValueError("Rejected relations require at least one rejection category")
        try:
            verdicts = ask_keyed(models, "extraction_reviewer", DOCUMENT_POLICY +
                "Act as the single evidence reviewer for each DOCUMENT relation. Check every semantic and evidence "
                "condition independently; accept only when ALL pass. Identify objections yourself; objections_resolved "
                "is true only if no substantive objection remains. Be strict about the exact quote's entailment, "
                "endpoint types, causal strength, direction, and qualifications. These are DOCUMENT candidates: "
                "evidence_status is supported ONLY when the supplied quote entails the exact relation; otherwise "
                "it is unsupported and accept must be false. Report all applicable rejection_categories: "
                "meaning_changed for stronger/different claims, quote_too_short when surrounding source text "
                "provides missing support, wrong_direction, wrong_kind, unsupported_claim, contradiction, or "
                "uncertain. Accepted answers must have an empty category list. For parallel source statements "
                "using the same predicate, explain an actual semantic or evidential difference before giving "
                "different verdicts. Never invent an ontology restriction. Write a concise concrete reason.",
                items, DocumentVerdict, page[0]["id"], validate=validate)
        except ModelResponseError as exc:
            trace.emit("extraction.review_batch_failed", candidate_ids=[r["id"] for r in page],
                       error=str(exc), error_type=type(exc).__name__, recoverable=True)
            if len(page) > 1:
                midpoint = len(page) // 2
                yield from review_page(page[:midpoint])
                yield from review_page(page[midpoint:])
            else:
                yield page[0], None, str(exc)
            return
        for row in page:
            yield row, verdicts[row["id"]], None

    for page in batches(rows, getattr(models, "batch_size", 4)):
        for row, verdict, error in review_page(page):
            counts = quality[row["chunk_id"]]
            if error is not None:
                row.update(accepted=False, review_status="unresolved", score=None, gates={},
                           decision_reason="No validated evidence review; excluded from graph: " + error)
                extraction = by_extraction[row["chunk_id"]]
                extraction["status"] = "incomplete"
                issue = dict(id=row["id"], reason=row["decision_reason"],
                             record={k: row[k] for k in ("source", "relation", "target", "evidence")})
                extraction.setdefault("issues", []).append(issue)
                trace.emit("extraction.unresolved", entity_id=row["id"], chunk_id=row["chunk_id"], **issue)
                counts["unresolved"] += 1
                trace.save("artifacts/extraction_issues.json", [dict(chunk_id=e["chunk_id"], **i)
                    for e in extractions for i in e.get("issues", [])])
            else:
                apply_verdict(row, verdict, trace, threshold=0)
                row["reviewer"] = row.pop("judge")
                row["review_status"] = "completed"
                counts["reviewed"] += 1
                counts["accepted" if row["accepted"] else "rejected"] += 1
            if row["accepted"]:
                duplicate = facts.add(row)
                if duplicate:
                    row["duplicate_of"] = duplicate["id"]
                    duplicate.setdefault("supporting_evidence", []).append({
                        k: row[k] for k in ("id", "chunk_id", "evidence", "evidence_start", "evidence_end")})
                else:
                    by_extraction[row["chunk_id"]]["relations"].append(row)
            decisions.append(row)
            trace.emit("debate.decision", entity_id=row["id"], decision=row)
            # Save every outcome, including the final item of a partial batch.
            trace.save("artifacts/extraction_review.json", decisions)
            trace.save("artifacts/extractions.json", extractions)
            trace.save("artifacts/extraction_quality.json", list(quality.values()))
            finish_item(trace, "extraction_review", row["id"], error)
    if not rows:
        trace.save("artifacts/extraction_review.json", [])
        trace.save("artifacts/extraction_quality.json", list(quality.values()))
    facts.rows[:] = [r for r in facts.rows if r.get("accepted")]
    for extraction in extractions:
        extraction["relations"][:] = [r for r in extraction["relations"] if r.get("accepted")]
        chunk_decisions = [r for r in decisions if r["chunk_id"] == extraction["chunk_id"] and r.get("review_status") != "unresolved"]
        quality[extraction["chunk_id"]].update(accepted=sum(r["accepted"] for r in chunk_decisions),
                                              rejected=sum(not r["accepted"] for r in chunk_decisions))
    trace.save("artifacts/extraction_review.json", decisions)
    trace.save("artifacts/extractions.json", extractions)
    trace.save("artifacts/extraction_quality.json", list(quality.values()))
    for counts in quality.values():
        trace.emit("extraction.chunk_review_summary", entity_id=counts["chunk_id"], **counts)
        print(f"  {counts['chunk_id']}: {counts['accepted']} accepted, "
              f"{counts['rejected']} rejected, {counts['unresolved']} unresolved", flush=True)
    from collections import Counter
    category_counts = Counter(category for row in decisions if not row["accepted"]
                              and row.get("review_status") != "unresolved"
                              for category in set(row.get("rejection_categories", [])))
    trace.save("artifacts/extraction_rejections.json", dict(
        scope="Completed semantic reviews; categories can overlap",
        counts=dict(category_counts.most_common()),
        rejected=[{k: row[k] for k in ("id", "chunk_id", "source", "relation", "target", "decision_reason")}
                  | {"categories": row.get("rejection_categories", [])}
                  for row in decisions if not row["accepted"] and row.get("review_status") != "unresolved"]))
    print("  Rejection categories (may overlap): " + ", ".join(
        f"{category}={count}" for category, count in category_counts.most_common()), flush=True)
    return decisions


def check_novelty(row, chunks, facts, models, trace):
    duplicate = facts.find(row)
    if duplicate:
        return dict(status="duplicate", evidence_ids=[duplicate["id"]],
                    reason="Canonical fact already present, including symmetric or inverse forms")
    return check_novelty_many([row], chunks, facts, models, trace)[row["id"]]


def check_novelty_many(rows, chunks, facts, models, trace):
    """Compare information only; truth and relevance belong to the debate."""
    results, pending = {}, []
    for row in rows:
        duplicate = facts.find(row)
        if duplicate:
            results[row["id"]] = dict(status="duplicate", evidence_ids=[duplicate["id"]],
                                     reason="Canonical fact already present")
        else:
            pending.append(row)
    references = [dict(id=chunk["id"], text=chunk["text"]) for chunk in chunks]
    references += [{key: fact.get(key) for key in
                    ("id", "source", "target", "relation", "relation_definition", "conditions", "modality")}
                   for fact in facts.rows]
    related = {row["id"]: {} for row in pending}
    checked = []
    for index, page in enumerate(batches(references, models.batch_size)):
        if not pending:
            break
        available = {row["id"]: ({ref["id"]: ref for ref in page} | related[row["id"]])
                     for row in pending}

        def validate(item, result):
            allowed = set(available[item["id"]])
            if not set(result.evidence_ids + result.related_reference_ids) <= allowed:
                raise ValueError("Novelty references must identify supplied information")
            if result.status == "duplicate" and not result.evidence_ids:
                raise ValueError("An already known assertion requires supporting reference IDs")

        items = [dict(id=row["id"],
                      candidate={key: row.get(key) for key in
                                 ("source", "target", "relation", "relation_definition", "conditions", "modality")},
                      earlier_references=list(related[row["id"]].values()))
                 for row in pending]
        errors = {}
        judgments = ask_keyed(models, "novelty_checker", NOVELTY_POLICY,
            items, Novelty, f"novelty_batch_{pending[0]['id']}_{index}",
            shared={"references": page}, validate=validate,
            on_error=lambda item, exc: errors.update({item["id"]: str(exc)}))
        checked.extend(ref["id"] for ref in page)
        remaining = []
        for row in pending:
            identifier = row["id"]
            if identifier in errors:
                results[identifier] = dict(status="unresolved", evidence_ids=[], reason=errors[identifier])
                continue
            judgment = judgments[identifier]
            for ref_id in judgment["related_reference_ids"] + judgment["evidence_ids"]:
                related[identifier][ref_id] = available[identifier][ref_id]
            saved_context = {ref["id"]: ref for ref in row.get("novelty_references", [])}
            row["novelty_references"] = list((saved_context | related[identifier]).values())
            trace.emit("debate.novelty_checked", entity_id=identifier,
                       references=list(available[identifier]), result=judgment)
            if judgment["status"] == "new":
                remaining.append(row)
            else:
                results[identifier] = judgment
        pending = remaining
    for row in pending:
        results[row["id"]] = dict(status="new", evidence_ids=[], checked_references=checked,
            related_reference_ids=list(related[row["id"]]),
            reason="The references do not already supply the candidate's asserted information")
    return results


def unresolved_candidate(row, error, trace):
    row.update(accepted=False, review_status="unresolved", score=None,
               decision_reason="No validated background decision: " + str(error))
    trace.emit("debate.unresolved", entity_id=row["id"], decision=row, error=str(error))


def review_background_many(rows, by_chunk, outline, concepts, models, trace):
    if not rows:
        return
    items = [dict(id=row["id"], **review_context(row, by_chunk[row["chunk_id"]], outline, concepts))
             for row in rows]
    chapter = items[0]["chapter"]
    for item in items:
        item.pop("chapter")
    by_id = {row["id"]: row for row in rows}

    def on_error(item, exc):
        unresolved_candidate(by_id[item["id"]], exc, trace)

    def validate(item, result):
        if result.candidate_id != item["id"]:
            raise ValueError("candidate_id must match item ID")
        if isinstance(result, BackgroundReview):
            validate_background_review(result, chapter)

    reviews = ask_keyed(models, "critic", BACKGROUND_POLICY +
        "Act as a fair critic of EACH actual assertion, not as an opponent required to reject it. "
        "List only substantive objections supported by a specific flaw or concrete uncertainty. "
        "Return objections=[] when you find none, and explain why the assertion is sound. "
        "Do not manufacture an objection because the knowledge is absent from the chapter; that absence "
        "is intentional. Evaluate the stated relation rather than an interpretation that changes its scope. "
        "Check whether the addition actually helps answer its supplied knowledge gap. Judge truth using "
        "your own general understanding, not source entailment. Keep validity checks consistent with objections.",
        items, BackgroundCritique, rows[0]["id"], shared={"chapter": chapter},
        validate=validate, on_error=on_error)
    for identifier, review in reviews.items():
        by_id[identifier]["critic"] = review
    items = [item for item in items if item["id"] in reviews]

    replies = ask_keyed(models, "proposer_rebuttal", BACKGROUND_POLICY +
        "You are the original proposer of each supplied claim. Your original_proposal and gap_analysis "
        "restore the claim and justification you proposed. Explain and defend that same assertion using "
        "your general subject knowledge, addressing every actual objection directly. If objections is "
        "empty, maintain and briefly justify your sound claim; do not invent an objection to rebut. "
        "Do not switch to the critic's role or concede merely because an objection was raised. "
        "Withdraw only if you identify a real error, unresolved uncertainty, or inability of this exact "
        "claim to address the gap. Explain the specific defect when withdrawing. "
        "A changed endpoint, predicate, condition, or modality would be a different claim: do not silently "
        "repair the assertion during rebuttal. Do not invent evidence or external citations.",
        [dict(item, objections=reviews[item["id"]]["objections"],
              original_proposal={key: value for key, value in by_id[item["id"]].get("original_proposal", {}).items()
                                 if key != "confidence"})
         for item in items],
        Response, rows[0]["id"], shared={"chapter": chapter}, validate=validate, on_error=on_error)
    for identifier, response in replies.items():
        row = by_id[identifier]
        row["rebuttal"] = response
        if response["position"] == "withdraw":
            withdraw_candidate(row, response, trace)

    # Withdrawals are terminal. The judge receives arguments only, never critic
    # scores/checks, confidence, or a proposer position to follow.
    items = [item for item in items if item["id"] in replies and replies[item["id"]]["position"] == "defend"]
    verdicts = ask_keyed(models, "judge", BACKGROUND_POLICY +
        "Independently adjudicate EACH exact assertion using your own general knowledge, its source "
        "context and knowledge gap, and the supplied objections and defense. Neither an argument nor "
        "agreement between roles is evidence. An empty objections list does not force acceptance; do "
        "your own assessment. A criticism is not automatically valid. Decide each semantic condition "
        "independently. Mark gap_addressed only when the actual added information helps resolve a "
        "supplied gap at the chapter's scope. Accept when the assertion is sound, useful, correctly "
        "qualified, and all substantive objections are resolved. Reject for a concrete remaining defect. "
        "Explain why each substantive objection is resolved or still valid. Source absence is expected "
        "for background knowledge and is not a reason to reject it.",
        [dict(item, objections=reviews[item["id"]]["objections"], reply=replies[item["id"]]["reason"])
         for item in items],
        BackgroundVerdict, rows[0]["id"], shared={"chapter": chapter}, validate=validate, on_error=on_error)
    for identifier, verdict in verdicts.items():
        apply_verdict(by_id[identifier], verdict, trace, threshold=None)


def debate(seeds, chunks, outline, concepts, relations, facts, models, trace, document_reviews=None,
           *, proposal_limit=0):
    if proposal_limit < 0:
        raise ValueError("background proposal limit must be nonnegative")
    candidates, transcripts = [], []
    by_chunk = {chunk["id"]: chunk for chunk in chunks}
    for seed in seeds:
        print(f"  Debate {seed['id']}: {seed['concept']}", flush=True)
        gaps = seed.get("gaps", [])
        if not gaps:
            transcripts.append(dict(seed=seed, proposal=None, candidate_ids=[], status="skipped",
                                    reason="No validated unanswered knowledge gap"))
            trace.save("artifacts/debate_progress.json", dict(candidates=candidates, transcripts=transcripts))
            finish_item(trace, "background_proposal", seed["id"])
            continue
        known = [{key: fact.get(key) for key in
                  ("id", "source", "relation", "target", "relation_definition", "origin", "conditions", "modality")}
                 for fact in facts.rows if seed["concept"] in (fact["source"], fact["target"])]
        source_context = [dict(id=cid, text=by_chunk[cid]["text"])
                          for cid in seed.get("chunk_ids", [seed["chunk_id"]])]
        gap_by_id = {gap["id"]: gap for gap in gaps}

        def validate_proposals(result):
            if proposal_limit and len(result.proposals) > proposal_limit:
                raise ValueError("Proposal count exceeds the configured per-seed budget")
            for value in result.proposals:
                if not set(value.gap_ids) <= set(gap_by_id):
                    raise ValueError("Each proposal must address supplied gap IDs")

        try:
            proposal = models.ask("proposer", BACKGROUND_POLICY +
                "First assess the supplied unanswered gaps against document_coverage and known_seed_facts; "
                "record a concise conclusion in gap_analysis about what is still missing. Then use your "
                "own general subject knowledge to supply useful explanatory assertions addressing those gaps. "
                "This is background expansion, not extraction: the assertion must contribute information "
                "not obtainable merely by paraphrasing, recombining, or reversing chapter statements. "
                "Do not restrict endpoints to the chapter's concept list. Introduce concepts when needed "
                "to explain the missing knowledge, reusing existing names for the same concepts. "
                "For each proposal identify gap_ids and explicitly describe its added_knowledge. "
                "Do not confuse a concept, its definition, and the document mentioning it. "
                "The seed must be one endpoint; source=null means the seed itself. "
                "Use a precise reusable predicate appropriate to the assertion. Available predicates are "
                "suggestions, not a closed vocabulary; define a new predicate when none fits. "
                "Preserve qualifications and avoid unsupported universality. "
                "Give your substantive justification in reason so you can defend it in debate. "
                "Do not repeat known facts, including equivalent inverse wording. "
                "Return only as many assertions as the gaps justify; there is no quota. Return no proposals "
                "when the gaps have been answered by accepted knowledge or cannot be answered responsibly "
                "from general understanding. Honor proposal_limit when non-null. Confidence is descriptive, "
                "not an admission criterion. No external texts, lookup, or invented citations.",
                {"seed": {key: seed[key] for key in ("concept", "definition", "kind")},
                 "chapter": {**{key: outline[key] for key in ("overview", "topics")},
                             "concepts": getattr(concepts, "chapter_names", []) or sorted(concepts.entries)},
                 "source_context": source_context, "document_coverage": seed.get("document_coverage"),
                 "gaps": gaps, "background_question": seed.get("background_question"),
                 "known_seed_facts": known, "proposal_limit": proposal_limit or None,
                 "available_relations": dict(relations.entries)},
                Expansion, seed["id"], validator=validate_proposals)
        except ModelResponseError as exc:
            transcripts.append(dict(seed=seed, proposal=None, candidate_ids=[], status="unresolved", reason=str(exc)))
            trace.save("artifacts/debate_progress.json", dict(candidates=candidates, transcripts=transcripts))
            finish_item(trace, "background_proposal", seed["id"], exc)
            continue
        finish_item(trace, "background_proposal", seed["id"])
        transcript = dict(seed=seed, proposal=proposal.model_dump(), candidate_ids=[])
        current = []
        for value in proposal.proposals:
            identifier = f"candidate_{len(candidates)+1:04d}"
            source = seed["concept"]
            context = dict(chapter=outline["overview"], source_context=source_context,
                           gaps=[gap_by_id[gap_id] for gap_id in value.gap_ids],
                           assertion=value.model_dump())
            row = dict(id=identifier, seed_id=seed["id"], source=source, target=value.target.name,
                       relation=value.relation, relation_definition=value.relation_definition,
                       origin="background", reason=value.reason, chunk_id=seed["chunk_id"],
                       paragraph_id=seed["paragraph_id"], conditions=value.conditions, modality=value.modality,
                       gaps=context["gaps"], gap_analysis=proposal.gap_analysis,
                       added_knowledge=value.added_knowledge, original_proposal=value.model_dump(),
                       source_context=source_context, known_seed_facts=known,
                       confidence=value.confidence, accepted=False, score=None, tier="related",
                       decision_reason="Unverified relation or self relation")
            candidates.append(row)
            transcript["candidate_ids"].append(identifier)
            try:
                if value.source is not None:
                    source = concepts.resolve_background(value.source, context, identifier)
                target = concepts.resolve_background(value.target, context, identifier)
                relation = relations.resolve(value.relation, value.relation_definition, source, target,
                                             context, identifier)
            except ModelResponseError as exc:
                unresolved_candidate(row, exc, trace)
                continue
            row.update(source=source, target=target, relation=relation or value.relation,
                       source_mention=value.source.model_dump() if value.source is not None else concepts.entries[source],
                       target_mention=value.target.model_dump(),
                       surface_relation=value.relation, surface_target=value.target.name)
            trace.emit("debate.proposed", entity_id=identifier, proposal=row.copy())
            if seed["concept"] not in (source, target):
                row["decision_reason"] = "Neither endpoint resolves to the seed"
            elif relation and target != source:
                row["relation_definition"] = relations.entries[relation]["definition"]
                current.append(row)

        novelties = check_novelty_many(current, chunks, facts, models, trace) if current else {}
        novel = []
        for row in current:
            row["novelty"] = novelties[row["id"]]
            if row["novelty"]["status"] == "new":
                novel.append(row)
            elif row["novelty"]["status"] in ("unresolved", "uncertain"):
                unresolved_candidate(row, row["novelty"]["reason"], trace)
            else:
                row["decision_reason"] = row["novelty"]["reason"]
        review_background_many(novel, by_chunk, outline, concepts, models, trace)

        # Every admitted assertion enters the same fact index. Only accepted
        # peers count as known; a rejected/withdrawn proposal is not knowledge.
        delta = FactIndex(relations)
        approved = []
        for row in novel:
            if row["accepted"]:
                try:
                    peer = check_novelty(row, [], delta, models, trace)
                except ModelResponseError as exc:
                    unresolved_candidate(row, exc, trace)
                    continue
                if peer["status"] in ("unresolved", "uncertain"):
                    unresolved_candidate(row, peer["reason"], trace)
                elif peer["status"] == "duplicate":
                    row.update(accepted=False, novelty=peer, decision_reason=peer["reason"])
                else:
                    delta.add(row)
                    approved.append(row)
        for row in approved:
            facts.add(row)
        for row in candidates:
            if row["seed_id"] == seed["id"]:
                row.setdefault("review_status", "completed")
                trace.emit("debate.decision", entity_id=row["id"], decision=row)
                trace.save("artifacts/debate_progress.json", dict(candidates=candidates, transcripts=transcripts + [transcript]))
                finish_item(trace, "background_candidate", row["id"],
                            row["decision_reason"] if row["review_status"] == "unresolved" else None)
        transcripts.append(transcript)
        trace.save("artifacts/debate_progress.json", dict(candidates=candidates, transcripts=transcripts))
    return dict(seeds=seeds, candidates=candidates, transcripts=transcripts,
                document_reviews=document_reviews or [], weights=[], dimensions=["domain_relevance"],
                decision_policy="Gap-directed general knowledge, novelty-only comparison, and independent semantic debate")
