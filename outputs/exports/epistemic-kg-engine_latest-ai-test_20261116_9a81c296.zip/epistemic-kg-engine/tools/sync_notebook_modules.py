"""Development helper: replace existing notebook modules from an explicit directory.

The notebook remains the implementation source. This tool never imports modules or
executes experiments. Temporary editable copies are not runtime dependencies.
"""
import argparse
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory', type=Path)
    parser.add_argument('modules', nargs='+')
    args = parser.parse_args()
    notebook = Path(__file__).resolve().parents[1] / '261273237.ipynb'
    document = json.loads(notebook.read_text(encoding='utf-8'))
    for name in args.modules:
        source = (args.directory / (name + '.py')).read_text(encoding='utf-8')
        compile(source, name, 'exec')
        cell = next(c for c in document['cells'] if c.get('metadata', {}).get('module') == name)
        cell['source'] = ('%%pipeline_module ' + name + '\n' + source).splitlines(keepends=True)
    notebook.write_text(json.dumps(document, ensure_ascii=False, indent=1) + '\n', encoding='utf-8')


if __name__ == '__main__':
    main()
