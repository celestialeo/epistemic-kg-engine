"""Verify a reviewed saved graph in Chrome with an isolated professor database."""
import argparse
import asyncio
import hashlib
import json
from pathlib import Path
import sys
import uuid

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from playwright.sync_api import sync_playwright, expect
from pipeline.explorer import create_app, load_snapshot
from pipeline.graph_quality import require_quality
from pipeline.professor import run_identity, topic_identity
from pipeline.student_store import StudentStore
from pipeline.submission import start_server, stop_server
import pipeline.submission as server


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('run', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    root = args.output or Path('outputs/professor_checks') / ('graph_quality_' + uuid.uuid4().hex[:10])
    root.mkdir(parents=True, exist_ok=True)
    snapshot = load_snapshot(args.run)
    graph = snapshot.graph
    require_quality(graph, required=True)
    source = snapshot.manifest.get('source_run')
    source_unchanged = None
    if source:
        digest = hashlib.sha256((Path(source)/'artifacts/graph.json').read_bytes()).hexdigest()
        assert digest == snapshot.manifest['source_graph_sha256'], 'Source graph changed'
        source_unchanged = True
    elif snapshot.manifest.get('config', {}).get('input'):
        input_path = Path(snapshot.manifest['config']['input'])
        assert input_path.read_bytes().decode('utf-8-sig') == (args.run/'input.txt').read_bytes().decode('utf-8'), 'Source text changed'
        source_unchanged = True
    store = StudentStore(root/'students.sqlite3')
    run_id = run_identity(snapshot)
    topic, title = topic_identity(snapshot)
    store.register_run(run_id, topic, title, snapshot)
    policy = asyncio.get_event_loop_policy()
    if sys.platform == 'win32':
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    try:
        def no_inference(*args, **kwargs):
            raise AssertionError('Opening a reviewed graph must not repeat inference')
        url = start_server(create_app([args.run], professor_store=store, runs_root=root/'empty',
                                      model_factory=no_inference))['url']
        server._server_state[0].config.timeout_graceful_shutdown = 2
    finally:
        asyncio.set_event_loop_policy(policy)
    errors = []
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(channel='chrome', headless=True)
            page = browser.new_page(viewport={'width':1440, 'height':1000})
            page.on('pageerror', lambda error: errors.append(str(error)))
            page.goto(url+'/professor?run='+run_id)
            expect(page.locator('#scope-topic')).to_have_value(topic)
            material = page.request.get(url+'/api/professor/runs/'+run_id+'/quiz-material').json()
            results = page.request.get(url+'/api/professor/runs/'+run_id+'/results').json()
            assert results['validation_records']['graph_quality']['status'] == 'passed'
            assert results['accepted'] == sum(e['origin']=='background' for e in graph['edges'])
            assert len(material['facts']) == sum(e['origin']=='background' for e in graph['edges'])
            assert all(not f['eligible'] for f in material['facts'] if f['fact']['origin']=='background')
            page.goto(url+'/professor/graph/'+run_id)
            expect(page.locator('#nodes .node')).to_have_count(len(graph['nodes']))
            expect(page.locator('#edges .edge')).to_have_count(len(graph['edges']))
            captions = page.locator('#edges .edge text').all_text_contents()
            assert captions == [e['label'] + (' ['+e['modality']+']' if e.get('modality') else '') for e in graph['edges']]
            page.wait_for_function('ticks >= 240')
            page.locator('#nodes .node circle').first.click()
            expect(page.locator('#details')).not_to_be_empty()
            # Search is the existing user control for isolating connected claims.
            # Verify every relationship with real pointer clicks in that view;
            # the unfiltered force layout can overlap unrelated edge captions.
            nodes = {n['id']: n for n in graph['nodes']}
            checked_edges = []
            page.screenshot(path=str(root/'overview-before-filter.png'), full_page=True)
            for edge in graph['edges']:
                page.locator('#search').fill(nodes[edge['source']]['label'])
                page.wait_for_function('ticks >= 240')
                edge_ids = page.evaluate('links.map(e => e.id)')
                page.locator('#edges .edge text').nth(edge_ids.index(edge['id'])).click()
                expect(page.locator('#details')).to_contain_text(edge['definition'])
                if edge.get('conditions'):
                    expect(page.locator('#details')).to_contain_text(edge['conditions'])
                checked_edges.append(edge['id'])
            page.locator('#reset').click()
            page.wait_for_function('ticks >= 240')
            page.screenshot(path=str(root/'reviewed-graph.png'), full_page=True)
            page.reload()
            expect(page.locator('#nodes .node')).to_have_count(len(graph['nodes']))
            page.set_viewport_size({'width':390, 'height':844})
            page.wait_for_function('ticks >= 240')
            page.screenshot(path=str(root/'reviewed-graph-mobile.png'), full_page=True)
            assert not errors, errors
            browser.close()
        report = dict(passed=True, run=str(args.run), nodes=len(graph['nodes']), edges=len(graph['edges']),
                      labels=sorted({e['label'] for e in graph['edges']}), javascript_errors=errors,
                      source_unchanged=source_unchanged, background_approval_required=True,
                      checked_edges=checked_edges, edge_selection='source search, then pointer click',
                      layout_limitation='Unfiltered relationship captions may overlap; search isolates connections.')
        (root/'verification.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
        print(json.dumps(dict(report, artifacts=str(root))))
    finally:
        try:
            stop_server()
        except RuntimeError:
            if server._server_state:
                server._server_state[0].force_exit=True
            stop_server()


if __name__ == '__main__':
    main()
