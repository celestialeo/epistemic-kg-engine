# Professor dashboard

Launch from the project directory with Ollama running and the saved run's model
installed:

```powershell
& .\.venv\Scripts\python.exe .\run_pipeline.py --interact --chapter ai-test
```

This **Interacting with graph** step prints one localhost URL and opens the latest
completed AI-test graph, quiz and professor controls on the same page. Use
`--no-open` to suppress the browser, `--explorer-port 8765` to choose a port, or
`--output-root PATH` for another run library. Omit `--chapter` to select the latest
completed run across inputs. No extraction or background generation is started.

A normal full pipeline run also opens this combined page at the end; add
`--no-explorer` to stop after reporting. For a separate class database, the
standalone `python -m pipeline.professor --database PATH` remains available, with
`--runs-root PATH`, `--port 8765` and `--no-open` options.

## Workflow

1. Add students to the roster. Each gets a distinct ID, even if names match.
2. Select a student and input topic. Refresh topics to discover newly completed
   runs. Failed and unfinished runs are excluded. Runs completed with issues are
   available with their status visible.
3. Use the recommended starting concept or choose one explicitly. Recommendations
   prioritize previously assessed gaps, then unassessed material, then review.
   Prior factual judgments are used only within the same graph version.
4. Click **Start quiz**, choose who is taking it from the created students, then
   click **Begin quiz**. This explicit choice links the new assessment to that
   student, even if a different student's overview was open. Canceling creates
   no assessment. The student's name stays visible during the quiz; resuming
   keeps its original student. The existing quiz generates and reviews
   graph-grounded questions, grades statements, supplies hints and reveals, and
   adapts subsequent questions to coverage. The examiner explicitly identifies
   which supplied facts the question asks for; context-only facts are not scored.
5. Inspect answers in assessment history. A professor can override each assessed
   fact's grade, add feedback and explain the decision. The original model result,
   every answer revision, and every override remain in the audit history.
6. Resume unfinished assessments from history, including after restarting the
   dashboard. A delivery retry uses the original request ID so an answer is not
   counted twice. A model failure leaves the last saved question intact.

## Scores, coverage and trends

- Correct facts earn 1, partial facts 0.5, and contradictions or facts not
  demonstrated earn 0. Missing an answer fact is not labeled a contradiction.
- A question score is the average over its requested facts. A session score is
  the average of its answered, scorable questions. Only the latest attempt at
  each question counts toward the score; attempt counts include all submissions.
- Questions without factual rubrics are unscored. Starting a quiz, receiving a
  hint, or revealing an answer alone does not create an assessed score.
- Assisted answers count toward scores and are explicitly marked. Coverage
  separately counts independently correct and assisted correct facts. Coverage
  uses the most recent answered judgment per fact, including professor overrides.
- An assessment count is a session with at least one scored answer. Started and
  completed counts are also shown; an unfinished assessment can have a score.
- An individual topic score is the latest assessed session for that input topic.
  Class scores average each assessed student's latest score, giving students
  equal weight. Unassessed students are excluded from averages and counted
  separately. Class trends show this evolving average at each assessment.
- Strongest and weakest are relative ranks among assessed input topics. With one
  assessed topic it is both. Review suggestions list assessed topics with less
  than full credit; unassessed topics appear separately as candidates to assess.
- Trend points retain the exact run used. A new graph version may assess
  different material: scores across versions are not standardized comparisons.
  Coverage in the topic table always refers to the latest run, even when the
  most recent score came from an older run. Historical run links are preserved.
- Overrides recalculate analytics and future recommendations. Original model
  grades remain available; the trend displays the current corrected scores.

## Persistence and scope

The SQLite database at `outputs/professor/students.sqlite3` stores students,
versioned graph snapshots, quiz checkpoints, answers, scores, feedback, request
receipts and override history. Updates to a quiz, its answer and retry receipt
commit together. Keep this file to retain history. Back it up while the dashboard
is stopped. Existing graph exploration/model logs continue under each run's
`explorer_sessions`; the original graph and pipeline result files are unchanged.

The dashboard is a local professor-operated application bound to localhost. It
does not implement separate authenticated student accounts or a shared remote
classroom service. Grading inherits the existing model's limitations, including
requiring explicit names for both entities in a credited statement. Professor
review is available for those cases. No extraction or background-knowledge logic
is changed by the dashboard.

## Verification

Run the HTTP/persistence and existing explorer regression tests:

```powershell
& .\.venv\Scripts\python.exe -m unittest tests.test_professor tests.test_explorer -q
```

The optional browser check uses installed Chrome and Playwright (test dependency
only: `python -m pip install playwright`):

```powershell
& .\.venv\Scripts\python.exe -m tests.browser_professor
```

It uses deterministic model fixtures and an isolated database, exercises the
complete five-question flow, overrides, analytics, reload recovery and graph
interaction, and saves desktop/mobile screenshots under `outputs/professor_checks`.
