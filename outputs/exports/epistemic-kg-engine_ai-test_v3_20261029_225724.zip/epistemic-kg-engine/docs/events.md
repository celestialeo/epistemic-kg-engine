# Event contract (version 1)

`events.jsonl` contains one JSON object per line. Its authoritative ordering is
`sequence`, which starts at 1 and increases by 1. IDs are local to a run; use
`(run_id, entity_id)` across runs. A simulator can seek by elapsed time or step
through the sequence without running models or connecting to Neo4j.

`timestamp` is UTC. New events also include `timestamp_local`, the same instant
with the computer's local UTC offset. Older events may omit that field. Run
folders now use local start time and an explicit UTC offset; historical IDs used
UTC and remain stable.

```json
{
  "schema_version": 1,
  "run_id": "run_...",
  "sequence": 42,
  "event_id": "event_000042",
  "timestamp": "2026-09-24T02:00:00+00:00",
  "elapsed_seconds": 5.123,
  "stage": "extraction",
  "event": "parse.completed",
  "entity_id": "chunk_001",
  "parent_id": "event_000040",
  "data": {"parsed": {"concepts": ["neuron"]}}
}
```

`parent_id` links an event to its initiating event, such as a model request or
stage start. It is nullable; graph entities are linked through IDs in `data`.
`entity_id` is the chunk, seed, candidate, graph node or graph edge concerned.
Setup is input → preflight. Processing is extraction → debate → graph → evaluation.
Chapter scope, document review, concept reconciliation and seed collection are
internal work in debate. Evaluation reconstructs and scores the text, then
generates the report. Every selected chapter has its own trace and run ID.

## Event families

| Family | Recorded information |
| --- | --- |
| `run.*`, `stage.*` | Lifecycle, settings, timing, failure trace |
| `input.*` | Read bytes/hash, decoded text, paragraphs, sentence boundaries, chunks, coverage |
| `service.*` | Model availability and metadata requests/responses |
| `cache.*` | Recovery source hash, parsed model metadata, validated entries and attributed response reuse |
| `model.*` | Role, prompt, JSON schema, options, explicit thinking flag, raw response, usage, duration, retry/error |
| `parse.*`, `validation.*` | Raw JSON content, parsed object, validated model |
| `extraction.*` | Exact quotes, adaptive unit splits, endpoint repairs, unresolved records and normalized output |
| `outline.*` | Segment summaries and their source chunk IDs |
| `registry.*` | Concept identity, contextual relation matches and verified new definitions |
| `health.failed` | Failing step, recent failure fraction, examples and early-stop reason |
| `health.warning` | Recoverable extraction/review failures; recent examples, without stopping execution |
| `seed.*` | Distinct extracted concepts selected for debate; descriptive phrases are excluded |
| `debate.*` | Proposal, ID coverage, chapter-wide novelty, semantic gates, verdict conflicts and final decision |
| `graph.*` | Full node additions/updates, full edge additions, endpoint validation |
| `embedding.*` | Seed-diversity embedding requests, responses and validation |
| `evaluation.*` | Reconstruction contexts, per-chunk and complete-document metrics, and summary statistics |
| `database.*` | Connections, queries/parameters/results/counters, transaction commit/rollback |
| `process.*` | Docker Compose command and captured output, when requested |
| `artifact.written` | Relative path, SHA-256, UTF-8 byte size |
| `presentation.*` | Browser opening result |

The complete Ollama response is retained, including reasoning fields when the
provider exposes them. A `reason` field is an explicit explanation, not a record
of private internal cognition. One `model.request` can have several subsequent
events; retries create new requests rather than overwriting unsuccessful output.
New `model.request` events include `data.think` (false by default). Historical
events without this field used the server default. Cache keys distinguish those
requests from explicit true/false settings and include the generation options.
Responses with `done_reason: "length"` raise `OutputLimitError` immediately;
their raw content is retained even if it happens to be syntactically valid JSON.
They are never cached as validated or retried with the same prompt.
The extractor handles this error by splitting its work unit into smaller parts.
`extraction.unit_split` records the original unit, absolute boundary, parent
chunk and boundary method. The original chunk/paragraph IDs remain unchanged.
Completed leaf units and their source ranges are saved in each extraction's
`units` array. Record counts have no schema cap.

`extraction.endpoint_repair_requested`, `extraction.endpoint_repair_completed`
and `extraction.endpoint_repair_failed` record targeted metadata repair.
The isolated model role is `concept_endpoint_repair`. The initial relation
schema embeds endpoint objects; missing metadata is allowed only at the wire
boundary in historical runs. Current generation requires full endpoint metadata,
uses the same kind enum as Concept, and keeps domain-specific labels in
`kind_detail`; normal live output does not need kind/definition repair.
`extraction.unresolved` preserves records that cannot be recovered.
`artifacts/extraction_issues.json` aggregates these records across chunks.
`extraction.quote_retry_requested` records each failed claim/relation index and
its exact-quote or sentence-overlap failure reason. The `extractor_quote_repair`
role repairs those records once per sentence; passed records are retained.
`extraction.evidence_checked` uses `attempt: 0` for the original and `attempt: 1`
for the repair. `extraction.quote_retry_completed` records recovered/unresolved
counts; `extraction.quote_retry_failed` records an unusable repair response.
Final `item.completed`/`item.unresolved` events use step `extraction_record`,
and only these final outcomes contribute to extraction health monitoring.
A sentence with no usable response contributes one unresolved item. Chunks
retain their aggregate status for reporting, but do not count as health failures.
Malformed extraction or normalization responses are isolated to the affected
work unit or record after bounded retries. Failed review batches emit
`extraction.review_batch_failed` and split to isolate individual candidates.
A candidate without a validated review has `review_status: unresolved` and
`accepted: false`; no verdict is fabricated. It makes the owning chunk incomplete.
Ordinary semantic rejections have `review_status: completed` and are never
counted as fatal processing failures. Every decision is saved immediately to
`extraction_review.json`; reviewed extractions and per-chunk counts are also
checkpointed. `extraction.chunk_review_summary` and `extraction_quality.json`
distinguish accepted, rejected and unresolved outcomes per chunk.
`health_warning.json` holds the latest warning; every warning and its recent
examples remain in the event stream. Service failures can still stop execution.
Normalized extraction events record the merged result; original responses
remain available in the model/parse events for each extraction work unit.

## Replaying the graph

Start with empty ordered node and edge maps. For `graph.node_added` and
`graph.node_updated`, assign `nodes[entity_id] = data.node`. For
`graph.edge_added`, assign `edges[entity_id] = data.edge`. At `graph.validated`,
these maps match `artifacts/graph.json` exactly, excluding its run-level header.
Updates preserve insertion order. Every relationship endpoint exists before its
edge event. Source and target refer to graph node IDs, never display names.

Paragraph and chunk IDs are sequential. Concept IDs are deterministic hashes of
normalized labels. Claim IDs include their chunk ID; candidates include their
seed and source chunk IDs in their records. Decisions retain rejected proposals;
only accepted proposals become background graph edges. Extracted relationships
also require semantic review before graph insertion. Equivalent source
assertions are combined into one edge with additional `supporting_evidence`.
Inverse and symmetric forms are compared using the run's relation registry.
Graph schema version 3 hashes normalized concept names (case, punctuation and
English singular/plural inflection). Nodes contain a name (`label`), one short
`definition`, and operational `id`, `kind: concept`, and `origin` fields. Context
never splits nodes. Endpoint kinds remain occurrence metadata for review rather
than graph identity. Relationships retain their own conditions, modality and
source evidence. Provenance is either `document` or `background`; document wins.

`registry.identity_reused` records reuse by normalized name. `registry.concepts_merged`
and `concept_reconciliation.json` record normalization redirects, without model
identity checks. `graph.canonicalized` records the final safeguard merging same-name
nodes and rerouting/deduplicating edges. Duplicate document evidence is preserved.
The saved graph artifact is authoritative after this final pass; earlier node/edge
addition events describe construction before final deduplication. Historical alias
verification events remain readable but new runs do not emit them.

`seed.filtered` records quantified/overlong names excluded from expansion;
`seeds.json` retains these exclusions and all model assessments. Eligible seeds
must identify an unanswered background question and a chapter topic.

New model roles include `segment_summarizer`, `chapter_summarizer`,
`seed_selector`, `extraction_reviewer`, `novelty_checker`, and isolated `concept_*` / `relation_*`
resolver and verifier roles. All calls are stateless. Registry roles may use
`--registry-model`; each request records the actual model. Role separation does
not make the underlying models statistically independent. No learned registry
state is shared between chapters. Background edges use
`verification_basis: model_knowledge`, not an external citation claim.

The extraction reviewer replaces the three-role debate for document facts,
using all the same evidence/semantic gates. Background facts retain all three
roles. Batched responses are keyed by item ID and validated per item. Novelty
checks still log every reference batch checked for each proposal.
Background critics/judges use a separate policy and chapter-level payload:
overview, exact topic list, and canonical chapter concepts, without source
chunks or quotes. They return `chapter_related` and `related_topic`; the latter
must name a supplied topic when the former is true. Numeric relevance is
descriptive. The proposer receives `known_seed_facts` in both directions.
Background proposals use the dynamic relation registry and may propose new
predicates. An optional source endpoint supports incoming seed relationships;
null or omitted source means the seed. The proposer schema has no `event_objects`.
`model.unused_field_dropped` warns when this obsolete field appears anywhere
in a response; the raw response and discarded value remain in the log.
Explicit extraction `acts_on` records still undergo their usual checks.

`item.completed` and `item.unresolved` record final work-item outcomes after
recovery. Only these outcomes drive health monitoring; `model.attempt_failed`
and `model.retry` do not. `artifacts/unresolved_items.json` is checkpointed
before a majority-failure stop and included in the report. Failed background
seeds and candidate decisions are also saved in `debate_progress.json`.

`extraction_rejections.json` counts semantic rejections by category, including
`meaning_changed`, `quote_too_short`, `wrong_direction`, and `wrong_kind`.
Categories can overlap. Malformed/unresolved reviews are counted separately.
Evidence may include the immediately adjacent source sentences, provided the
exact continuous quote overlaps its extraction work unit. Original character
offsets are preserved and semantic entailment still must pass.
`registry.identity_candidates` is historical. New concept identity decisions are
name-based, not context-specific model decisions.
Memory cache hits include the source event/run just like resumed cache hits.

`start` and `end` are zero-based Unicode character offsets in the decoded
`input.txt` snapshot, with an exclusive end. Evidence offsets use the same
coordinate system. The pipeline preserves internal whitespace and checks exact
word coverage; whitespace between paragraphs/chunks is represented by offsets
rather than duplicated inside chunks. These are Python Unicode offsets, not
UTF-16 indexes: JavaScript consumers should use `Array.from(text)` when slicing
documents containing characters outside the Basic Multilingual Plane.

## Completion and failures

Trust `manifest.json.status` and the final `run.completed` event together.
Status `completed_with_issues` means the pipeline finished with unresolved work
or incomplete evaluation and returned exit code 2. The manifest lists
`incomplete_extraction_chunks`, `evaluation_status`, and `reconstruction_score`;
the report links to unresolved records. `evaluation.context_built` records the
claims, concepts and relations supplied to the reconstructor, without source
chunk text or evidence quotes. Chunks without grounded content are evaluated as
empty reconstructions. Unresolved evaluations have null scores. Per-chunk results
are checkpointed in `artifacts/evaluation_progress.json`; the final result is
`artifacts/evaluation.json`, and `reconstruction.txt` joins the rebuilt chunks in
source order. `final_score` is the complete-document score, never a substitute
chunk mean. The final document alignment has separate context/output budgets,
recorded in configuration and each request's effective options and cache key.
`run.failed` carries the full traceback and the run closes with failure status.
A stopped run can contain useful partial events and artifacts but no final graph
or report. A forced process kill may leave status `running`; no completion event
means the run is incomplete. Each event is flushed, but this is not a guarantee
against disk failure or power loss. Discard an incomplete trailing JSONL line
when inspecting a forcibly terminated process.

The manifest hashes saved artifacts, except itself and the live event/console
logs. `event_counts_before_finalization` explicitly excludes the final manifest
write and closing event. Read the stream for exact final event counts. Console
output is in `run.log`; structured model and database data is in `events.jsonl`.


## Explorer quizzes

Explorer logs live in the source run's `explorer_sessions/explorer_<id>/events.jsonl`.
`quiz.request` records each action, page/session/question IDs and submitted answer.
`quiz.state` records the current question, cumulative edge/node colors and coverage.
`quiz.error` records failures. Model requests/responses share the explorer trace.
`quiz/<quiz_id>.json` checkpoints the question state and full answer history.
Request IDs make retries idempotent; stale question IDs cannot advance another
question. Hints and reveals do not increment the question number or earn coverage.

Each round contains at most five questions: highest document-degree concept for Q1;
its unmapped connections to highest-degree neighbors for Q2/Q3; green neighbors
with the most unmapped relationships for Q4/Q5. Partial and contradicted edges are
still unmapped. No eligible neighbor produces an explicit current-concept/review
fallback. Q5's answer completes the round. Continue explicitly starts another five
while preserving mapped relationships. Coverage separates independent and assisted
matches, and does not count reveal-only relationships as recalled.
